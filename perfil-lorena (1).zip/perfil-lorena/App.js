import {
  Text,
  StyleSheet,
  TouchableOpacity,
  Button,
  Image,
  View,SafeAreaView
} from 'react-native';
//import {  } from 'react-native-safe-area-context';

function App() {
  return (
    <SafeAreaView style={styles.container}>
      <View  style={styles.profileContainer}>
        <Image source={require('./assets/foto.JPG')}style={styles.profileImage} />
        <Text style={styles.text}>Nome: Lorena Sousa</Text>
        <Text style={styles.text}>Número: 1899655-3439</Text>
        <Text style={styles.text}>Solteira(a)</Text>
        <Button title = "Editar"/>
        <Button title = "Enviar Mensagem"/>
        <Button title = "seguir"/>
      </View>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFC0CB',
  },
  profileContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  profileImage: {
    width: 150,
    height: 150,
    borderRadius: 75,
  },
  text: {
    fontSize: 16,
    marginBottom: 10,
  },
  buttonContainer: {
    alignItems: 'center',
  },
  button: {
    width: 200,
    padding: 10,
    borderRadius: 8,
    marginBottom: 10,
  },
  buttonText: {
    fontSize: 16,
    color: '#FFFFFF',
    textAlign: 'center',
  },
});

export default App;
